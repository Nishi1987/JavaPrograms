/*
 * Simply put, recursion is when a function calls itself. That is, in the course of the function definition there is 
 * a call to that very same function. At first this may seem like a never ending loop, or like a dog chasing its tail.
 *  It can never catch it. So too it seems our method will never finish. This might be true is some cases, 
 *  but in practise we can check to see if a certain condition is true and in that case exit (return from) our method.
 *   The case in which we end our recursion is called a base case . Additionally, just as in a loop, we must change 
 *   some value and incremently advance closer to our base case.
 * 
 * 
 * Every recursion should have the following characteristics.

	A simple base case which we have a solution for and a return value.
	A way of getting our problem closer to the base case. I.e. a way to chop out part of the problem to get a somewhat simpler problem.
	A recursive call which passes the simpler problem back into the method.


Then why use it? It seems that there is always an iterative solution to any problem that can be solved recursively. 
Is there a difference in computational complexity? No. 
Is there a difference in the efficiency of execution? Yes, in fact, the recursive version is usually less efficient 
because of having to push and and pop recursions on and off the run-time stack, so iteration is quicker. 
On the other hand, you might notice that the recursive versions use fewer or no local variables.


So why use recursion? The answer to our question is predominantly because it is easier to code a recursive solution 
once one is able to identify that solution. The recursive code is usually smaller, more concise, more elegant, possibly 
even easier to understand, though that depends on ones thinking style. But also, there are some problems that are very 
difficult to solve without recursion.

 */
package recursion;

public class RecursionDemo {
	
	/**
	 * main method
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println("myFactorial -" + myFactorial(5));
		
		String string = "ABC";
		//stringPermutations("", string);
		 permutation("", string); 
	}
	
	

	/**
	 * Let's write the factorial function recursively. 
	 * @param integer
	 * @return
	 */
	public static int myFactorial(int integer) {
		if (integer == 1)
			return 1;
		else {
			return (integer * (myFactorial(integer - 1)));
			
		}
	}
	
	/**
	 * String  permutation
	 * @param newstring
	 * @param remaining
	 */
	public static void stringPermutations(String newstring, String remaining) {
		if (remaining.length() == 0)
			System.out.println(newstring);

		for (int i = 0; i < remaining.length(); i++) {
			String newRemaining = remaining.replaceFirst(remaining.charAt(i)+ "", "");
			stringPermutations(newstring + remaining.charAt(i), newRemaining);
		}
	}
	
	/**
	 * @param prefix
	 * @param str
	 */
	private static void permutation(String prefix, String str) {
	    int n = str.length();
	    if (n == 0) System.out.println(prefix);
	    else {
	        for (int i = 0; i < n; i++)
	            permutation(prefix + str.charAt(i), str.substring(0, i) + str.substring(i+1, n));
	    }
	}

}
