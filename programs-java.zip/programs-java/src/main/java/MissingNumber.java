

import java.util.Arrays;
import java.util.Scanner;


public class MissingNumber {
	public static void main(String args[]) {
		int[] iArray = new int[500];
		String[] sArray = new String[5];
		Scanner scanIn = new Scanner(System.in);
		for (int i = 0; i < sArray.length; i++) {
				String Num = scanIn.nextLine() ;
				if(! Num.isEmpty())
			    iArray[i] = Integer.parseInt(Num);
		}
		int maxNumber = getMaxNumner2(iArray);
		findMissingElement(iArray, maxNumber);

	}

	private static void findMissingElement(int[] aNumbers, int aTotalElement) {
		int i = 0;
		boolean missingElement;
		while (i < aTotalElement) {
			missingElement = true;
			for (int j = 0; j < aNumbers.length; j++) {
				if (aTotalElement == aNumbers[j]){
					missingElement = false;
				}
			}
			if (missingElement == true) {
				System.out.println(aTotalElement);
			}
			--aTotalElement;
		}
	}
	
	/**
	 * 
	 * if you can change the order of the elements
	 * @param iArray
	 * @return
	 */
	private static int getMaxNumner(int[] iArray){
		 Arrays.sort(iArray);
		 int max = iArray[iArray.length - 1];
		return max;
		
	}
	
	/**
	 * 
	 * If you can't change the order of the elements
	 * @param iArray
	 * @return
	 */
	private static int getMaxNumner2(int[] iArray){
		 
		 int max = Integer.MIN_VALUE;
		 for(int i = 0; i < iArray.length; i++) {
			 if(iArray[i] > max){
				 max = iArray[i];
			 }
		 }
		return max;
		
	}
}
