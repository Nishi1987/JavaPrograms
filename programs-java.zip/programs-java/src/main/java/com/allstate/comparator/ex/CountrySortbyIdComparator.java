package com.allstate.comparator.ex;

import java.util.Comparator;

public class CountrySortbyIdComparator implements Comparator<Country> {

	@Override
	public int compare(Country country1, Country country2) {

		return (country1.getCountryId() < country2.getCountryId()) ? -1
				: (country1.getCountryId() > country2.getCountryId()) ? 1 : 0;
		//By Name
		//return country1.getCountryName().compareTo(country2.getCountryName());
	}

}
