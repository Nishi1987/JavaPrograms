package com.allstate.serializing;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class TestSerialization {
	public static void main(String[] args) {

		try {
			Studentinfo si = new Studentinfo("Anuj", 144, "Allstate");
			FileOutputStream fos = new FileOutputStream("student1.ser");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(si);
			oos.close();
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
