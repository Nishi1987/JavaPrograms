package com.allstate.serializing;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Test {
	public static void main(String[] args) {
		
		try {
			ChildSerialized si = new ChildSerialized("AnujTripathi", 144, "Allstate");
			FileOutputStream fos = new FileOutputStream("parent.ser");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(si);
			oos.close();
			fos.close();
			
			FileInputStream fis = new FileInputStream("parent.ser");
			 ObjectInputStream ois = new ObjectInputStream(fis);
			 ChildSerialized objChildSerialized = (ChildSerialized)ois.readObject();
			 System.out.println(objChildSerialized.getClass());
			 System.out.println(objChildSerialized.strName);
			 System.out.println(ChildSerialized.contact);
			 System.out.println(objChildSerialized.name);
			 System.out.println(objChildSerialized.iIndex);
			 System.out.println(objChildSerialized.rid);
			 System.out.println(objChildSerialized.objNot);
			   
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

}
