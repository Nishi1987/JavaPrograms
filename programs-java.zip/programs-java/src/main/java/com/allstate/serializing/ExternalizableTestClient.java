package com.allstate.serializing;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ExternalizableTestClient {
	public static void main(String[] args) 
		    throws Exception {
		    
		ExternalizableDemo userWrite = new ExternalizableDemo(3, "johndoe", "John Doe");
		    FileOutputStream fos = new FileOutputStream("testfile");
		    ObjectOutputStream oos = new ObjectOutputStream(fos);
		    oos.writeObject(userWrite);
		    oos.flush();
		    oos.close();

		    ExternalizableDemo userRead;
		    FileInputStream fis = new FileInputStream("testfile");
		    ObjectInputStream ois = new ObjectInputStream(fis);
		    userRead = (ExternalizableDemo)ois.readObject();
		    ois.close();
		    
		    System.out.println("username: " + userRead.getUsername());
		    System.out.println("username: " + userRead.getId());

		  }

}
