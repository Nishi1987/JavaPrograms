package com.allstate.serializing;

import java.io.Serializable;

public class ChildSerialized extends ParentClass implements Serializable{
	String name;
	transient  int rid; // transient keyword will prevent that data member from being serialized. while deserialization it will take the defalut value. in this case 0. 
	static String contact; //tatic members are never serialized because they are connected to class not object of class.

	ChildSerialized(String n, int r, String c) {
		this.name = n;
		this.rid = r;
		this.contact = c;
	}
}
