package com.allstate.serializing;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;



public class ExternalizableDemo implements Externalizable {

	private int id;
	private String username;
	private String email;

	public ExternalizableDemo(int id, String username, String email) {
		this.id = id;
		this.username = username;
		this.email = email;
	}

	public ExternalizableDemo() {

	}

	public int getId() {
		return id;
	}

	public String getUsername() {
		return username;
	}

	public String getEmail() {
		return email;
	}

	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeInt(id << 2);
		out.writeObject(username);
		out.writeObject(email);
	}

	@Override
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		id = in.readInt() >> 2;
		username = (String) in.readObject();
		email = (String) in.readObject();
	}
	
	
}
