package com.allstate.serializing;

public class NotSerializing {

	String strNotSer = "Tripathi";
}
