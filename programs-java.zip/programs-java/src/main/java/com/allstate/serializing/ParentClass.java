package com.allstate.serializing;

public class ParentClass {
	
	int iIndex = 10;
	String strName = "Anuj";
	NotSerializing objNot;

}
