package com.allstate.find.top.two;

public class TwoMaxNumbers {

	public static void main(String a[]) {
		int[] A = { 1, 2, 3, 5, 8, 9, 4, 6 }; // answer should be 9 and8
		int top1 = 1;
		int top2 = 0;
		for (int i = 0; i < A.length; i++) {
			if (top1 < A[i]) {
				top2 = top1;
				top1 = A[i];
			}
		}
		System.out.println(top1 + "  and  " + top2);
	}

}
