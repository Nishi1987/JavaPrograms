package com.allstate.find.missing.number;

import java.util.Arrays;
import java.util.BitSet;

public class MissingNumberInArray {
	public static void main(String args[]) {

		int[] iArray = new int[] {3,1,4,5,6};
		printMissingElement(iArray, 100);
		//findMissingNumber(iArray);
		
		/*int number = 5;
		
		for (int i = 0; i < iArray.length; i++) {
			
			if ( number == iArray[i] + iArray[i+1])
				System.out.println("Position" + i );
		}*/
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	private static void printMissingElement(int[] numbers, int total_element) {
		int i = 0;
		boolean missingElement;
		while (i < total_element) {
			missingElement = true; // initialized to true means element is missing.
			for (int j = 0; j < numbers.length; j++) {
				if (total_element == numbers[j]) // each array element with total element.
				{
					missingElement = false; // means element is not missing.
				}
			}
			if (missingElement == true) {
				System.out.println("Anuj" + total_element);
			}
			--total_element;
		}
	}	
	
	private static void findMissingNumber(int[] number){
		for (int i = 0; i < number.length -1; i++) {
			int j = i+1;
			int difference = number[j] - number[i] ;
				if(difference != 1){
					int missing_num = number[i] + 1;
					for (int k = difference; k > 1 ; k--) {
						System.out.println("Missing Number is " + missing_num);
						missing_num++;
					}
				}
		}
	}

	/**
	 * Java method to find missing number in array of size n containing numbers
	 * from 1 to n only. can be used to find missing elements on integer array
	 * of numbers from 1 to 100 or 1 - 1000
	 */
	private static int getMissingNumber(int[] numbers, int totalCount) {
		int expectedSum = totalCount * ((totalCount + 1) / 2);
		int actualSum = 0;
		for (int i : numbers) {
			actualSum += i;
		}

		return expectedSum - actualSum;
	}

	
		

}
