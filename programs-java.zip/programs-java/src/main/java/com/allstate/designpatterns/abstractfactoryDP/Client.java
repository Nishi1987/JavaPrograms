package com.allstate.designpatterns.abstractfactoryDP;

public class Client {
	@SuppressWarnings("null")
	public static void main(String[] args) {
		AnimalFactory objAnimalFactory = null;
		String strSpeakSound;
		Animal objAnimal = null;
		objAnimalFactory = objAnimalFactory.getAnimalFactory("land");
		System.out.println(objAnimalFactory.getClass().getName());
		objAnimal = objAnimalFactory.getAnimal("lion");
		strSpeakSound = objAnimal.speak();
		System.out.println(objAnimal.getClass().getName());
		System.out.println("Animal Speak Sound is " + strSpeakSound);
		
	}

}
