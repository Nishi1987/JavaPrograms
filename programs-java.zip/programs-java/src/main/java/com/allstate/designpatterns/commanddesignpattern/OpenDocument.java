package com.allstate.designpatterns.commanddesignpattern;

public class OpenDocument implements Command{
	
	private WordDocument objWordDocument;

	public OpenDocument(WordDocument objWordDocument) {
		super();
		this.objWordDocument = objWordDocument;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		objWordDocument.openDocument();
		
	}

}
