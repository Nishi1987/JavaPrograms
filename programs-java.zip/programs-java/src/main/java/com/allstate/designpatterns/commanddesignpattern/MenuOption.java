package com.allstate.designpatterns.commanddesignpattern;
/*
 * This is the invoker
 */
public class MenuOption {
	
	Command objOpenComand;
	Command objSaveCommand;
	Command objCloseCommand;
	public MenuOption(Command objOpenComand, Command objSaveCommand,
			Command objCloseCommand) {
		super();
		this.objOpenComand = objOpenComand;
		this.objSaveCommand = objSaveCommand;
		this.objCloseCommand = objCloseCommand;
	}
	
	
	public void clickOpen(){
		objOpenComand.execute();
	}
	
	public void clickSave(){
		objSaveCommand.execute();
	}
	
	public void clickClose(){
		objCloseCommand.execute();
	}
	

}
