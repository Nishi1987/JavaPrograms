package com.allstate.designpatterns.commanddesignpattern;

/*
 * Receiver 
 */
public class WordDocument {
	
	public void openDocument(){
		System.out.println("Document is opened !!!");
	}
	
	public void saveDocument(){
		System.out.println("Document is Saved !!!");
	}
	
	public void closeDocument(){
		System.out.println("Document is Closed !!!");
	}

}
