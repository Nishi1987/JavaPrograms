package com.allstate.designpatterns.commanddesignpattern;

public class Client {
	public static void main(String[] args) {
		
		WordDocument objWordDocumet = new WordDocument();
		
		Command objOpenCommand = new OpenDocument(objWordDocumet);
		Command objSaveCommand = new SaveDocument(objWordDocumet);
		Command objCloseCommand = new CloseDocument(objWordDocumet);
		
		MenuOption objMenu = new MenuOption(objOpenCommand, objSaveCommand, objCloseCommand);
		
		objMenu.clickOpen();
		objMenu.clickSave();
		objMenu.clickClose();
		
	}

}
