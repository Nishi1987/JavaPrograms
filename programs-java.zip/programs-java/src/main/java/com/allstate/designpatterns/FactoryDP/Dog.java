package com.allstate.designpatterns.FactoryDP;

public class Dog implements Animal{

	@Override
	public String speak() {
		return "Bark Bark !!!";
		
	}

}
