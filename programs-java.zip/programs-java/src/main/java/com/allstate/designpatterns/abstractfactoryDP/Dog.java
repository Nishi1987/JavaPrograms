package com.allstate.designpatterns.abstractfactoryDP;

public class Dog implements Animal{

	@Override
	public String speak() {
		return "Bark Bark !!!";
		
	}

}
