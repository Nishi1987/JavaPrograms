package com.allstate.designpatterns.abstractfactoryDP;

public class SeaAnimalFactory extends AnimalFactory{

	@Override
	public Animal getAnimal(String strAnimalType) {
		
		Animal objAnimal = null;
		
		if("shark".equalsIgnoreCase(strAnimalType)){
			objAnimal = new Shark();
		}
		
		if("octopus".equalsIgnoreCase(strAnimalType)){
			objAnimal = new Octopus();
		}
		
		return objAnimal;
	}

}
