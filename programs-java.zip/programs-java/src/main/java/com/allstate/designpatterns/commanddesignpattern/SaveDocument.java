package com.allstate.designpatterns.commanddesignpattern;

public class SaveDocument implements Command{
	private WordDocument objWordDocument;
	

	public SaveDocument(WordDocument objWordDocument) {
		super();
		this.objWordDocument = objWordDocument;
	}


	@Override
	public void execute() {
		// TODO Auto-generated method stub
		objWordDocument.saveDocument();
	}

}
