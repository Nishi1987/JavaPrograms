package com.allstate.designpatterns.FactoryDP;

public interface Animal {
	
	public String speak();

}
