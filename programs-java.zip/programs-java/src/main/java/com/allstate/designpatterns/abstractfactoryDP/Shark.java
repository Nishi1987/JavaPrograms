package com.allstate.designpatterns.abstractfactoryDP;

public class Shark implements Animal{

	@Override
	public String speak() {
		// TODO Auto-generated method stub
		return "Can not speak";
	}

}
