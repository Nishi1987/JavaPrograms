package com.allstate.designpatterns.commanddesignpattern;

public interface Command {
	
	public void execute();

}
