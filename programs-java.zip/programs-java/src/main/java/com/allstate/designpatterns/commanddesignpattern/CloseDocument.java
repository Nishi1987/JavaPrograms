package com.allstate.designpatterns.commanddesignpattern;

public class CloseDocument implements Command{
	
	private WordDocument objWordDocument;
	

	public CloseDocument(WordDocument objWordDocument) {
		super();
		this.objWordDocument = objWordDocument;
	}


	@Override
	public void execute() {
		// TODO Auto-generated method stub
		objWordDocument.closeDocument();
		
	}

}
