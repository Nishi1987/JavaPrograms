package com.allstate.designpatterns.SinletonDP;

public class Singleton {

	// Static member hold onlu one instance of a singleton class
	private static Singleton objSingletonInstance;

	// private constructor prevents any other class to instantiate
	private Singleton() {
	}

	// providing global point of access
	public static Singleton getSingletonInstance() {

		if (null == objSingletonInstance) {
			objSingletonInstance = new Singleton();
			System.out.println("Inside null check, object is created :"
					+ objSingletonInstance.toString());
		}
		return objSingletonInstance;
	}
	
	public void printSingletonInstance(){
		System.out.println("Inside Print objSingletonInstance" + objSingletonInstance.toString());
	}
}
