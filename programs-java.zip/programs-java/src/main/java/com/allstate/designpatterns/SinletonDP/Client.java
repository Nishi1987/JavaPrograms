package com.allstate.designpatterns.SinletonDP;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Singleton.getSingletonInstance().printSingletonInstance();
		Singleton.getSingletonInstance().printSingletonInstance();
		Singleton.getSingletonInstance().printSingletonInstance();
		Singleton.getSingletonInstance().printSingletonInstance();
		
	}

}
