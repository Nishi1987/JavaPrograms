package com.allstate.designpatterns.FactoryDP;

public class Client {
	public static void main(String[] args) {
		AnimalFactory objAnimalFactory = new AnimalFactory();
		Animal objAnimal = null;
		String strSpeakSound;
		objAnimal = objAnimalFactory.getAnimal("duck");
		strSpeakSound = objAnimal.speak();
		System.out.println(objAnimal.getClass().getName());
		System.out.println("Animal Speak Sound is " + strSpeakSound);
		
	}

}
