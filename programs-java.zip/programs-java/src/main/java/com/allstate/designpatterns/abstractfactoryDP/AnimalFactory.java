package com.allstate.designpatterns.abstractfactoryDP;

public abstract class AnimalFactory {
	
	public abstract Animal getAnimal(String strAnimalType);
		
	public  AnimalFactory getAnimalFactory(String strAnimalFactoryType){
		
		AnimalFactory objAnimalFactory = null;
		
		if("land".equalsIgnoreCase(strAnimalFactoryType)){
			objAnimalFactory = new LandAnimalFactory();
		}
		
		if("sea".equalsIgnoreCase(strAnimalFactoryType)){
			
		}
		
		return objAnimalFactory;
		
		
	}
		


}
