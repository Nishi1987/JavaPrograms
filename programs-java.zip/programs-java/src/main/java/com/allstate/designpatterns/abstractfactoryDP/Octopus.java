package com.allstate.designpatterns.abstractfactoryDP;

public class Octopus implements Animal{

	@Override
	public String speak() {
		// TODO Auto-generated method stub
		return "Squackes";
	}

}
