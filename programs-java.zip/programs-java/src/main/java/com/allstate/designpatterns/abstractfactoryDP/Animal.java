package com.allstate.designpatterns.abstractfactoryDP;

public interface Animal {
	
	public String speak();

}
