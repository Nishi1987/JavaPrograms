package com.allstate.designpatterns.abstractfactoryDP;


public class LandAnimalFactory extends AnimalFactory{

	@Override
	public Animal getAnimal(String strAnimalType) {
		
		Animal objAnimal = null;
		
		if("dog".equalsIgnoreCase(strAnimalType)){
			objAnimal = new Dog();
		}
		
		if("duck".equalsIgnoreCase(strAnimalType)){
			objAnimal = new Duck();
		}
		
		if("lion".equalsIgnoreCase(strAnimalType)){
			objAnimal = new Lion();
		}
		
		return objAnimal;
	}

}
