package com.allstate.designpatterns.abstractfactoryDP;

public class Duck implements Animal{

	@Override
	public String speak() {
		// TODO Auto-generated method stub
		return "Quack Quack !!!";
		
	}

}
