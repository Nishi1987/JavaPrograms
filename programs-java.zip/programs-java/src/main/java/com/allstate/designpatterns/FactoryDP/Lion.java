package com.allstate.designpatterns.FactoryDP;

public class Lion implements Animal{

	@Override
	public String speak() {
		// TODO Auto-generated method stub
		return "Roarrrrr !!!";
	}

}
