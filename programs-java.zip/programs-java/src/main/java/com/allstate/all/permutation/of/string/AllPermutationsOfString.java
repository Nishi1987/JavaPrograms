package com.allstate.all.permutation.of.string;

public class AllPermutationsOfString {

	public static void main(String[] args) {

		String string = "ABC";
		AllPermutationsOfString.stringPermutations("", string);

	}

	public static void stringPermutations(String newstring, String remaining) {
		if (remaining.length() == 0)
			System.out.println(newstring);

		for (int i = 0; i < remaining.length(); i++) {
			String newRemaining = remaining.replaceFirst(remaining.charAt(i)+ "", "");
			stringPermutations(newstring + remaining.charAt(i), newRemaining);
		}

	}
}
