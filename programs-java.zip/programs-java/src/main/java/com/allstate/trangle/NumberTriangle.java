package com.allstate.trangle;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class NumberTriangle {

	public static void main(String[] args) {
		
		pyramidOfNumbers();
		
	}
	
	public static void pyramidOfNumbers(){
		Scanner a=new Scanner(System.in);
		int  x =a.nextInt();
	    for (int i = 1; i <= x; i++) {

	        for (int j = 1; j <= x - i; j++)
	            System.out.print("   ");

	        for (int k = i; k >= 1; k--)
	            System.out.print("  " + k);

	        for (int k = 2; k <=i; k++)
	            System.out.print("  " + k);
	        System.out.println();
	    }  
	}
	
	public static void printTrangle(){
		String str;
		int no;

		try {
			BufferedReader obj = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("Enter how many lines of triangle you want to generate : ");
			System.out.flush();
			str = obj.readLine();
			no = Integer.parseInt(str);
			
			//Scanner a=new Scanner(System.in);
			//int n=a.nextInt();
			

			for (int i = 1; i <= no; i++) {
				for (int j = 1; j <= i; j++) {
					System.out.print("  " + i + "  ");
					System.out.flush();
				}
				System.out.println("\n");
			}
		} catch (Exception e) {
		}
	}

}
