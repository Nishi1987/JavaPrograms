package com.allstate.io.operations.video.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ReadWriteVideoFile {

public static void main(String[] args) throws IOException {
	


        File file = new File("C:/Anuj/Kill Bill/Wildlife.wmv");

        FileInputStream fin = new FileInputStream(file);
        byte b[] = new byte[(int)file.length()];
        fin.read(b);

        File nf = new File("C:/K.mp4");
        FileOutputStream fw = new FileOutputStream(nf);
        fw.write(b);
        fw.flush();
        fw.close();

    }
}

