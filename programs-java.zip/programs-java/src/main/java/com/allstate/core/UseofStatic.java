/*
 * Static variable

    It is a variable which belongs to the class and not to object(instance)
    Static variables are initialized only once , at the start of the execution . These variables will be initialized first, before the initialization of any instance 
Variables
    A single copy to be shared by all instances of the class
    A static variable can be accessed directly by the class name and doesn�t need any object
    Syntax : <class-name>.<variable-name>


static method

    It is a method which belongs to the class and not to the object(instance)
    A static method can access only static data. It can not access non-static data (instance variables)
    A static method can call only other static methods and can not call a non-static method from it.
    A static method can be accessed directly by the class name and doesn�t need any object
    Syntax : <class-name>.<method-name>
    A static method cannot refer to �this� or �super� keywords in anyway

Side Note:

    main method is static , since it must be be accessible for an application to run , before any instantiation takes place.



Static methods (in fact all methods) as well as static variables are stored in the PermGen section of the heap, since they are part of the reflection data (class related data, not instance related).

Update for clarification:

Note that only the variables and their technical values (primitives or references) are stored in PermGen space.

If your static variable is a reference to an object that object itself is stored in the normal sections of the heap (young/old generation or survivor space). Those objects (unless they are interal objects like classes etc.) are not stored in PermGen space.

Example:

static int i = 1; //the value 1 is stored in the permgen section
static Object o = new SomeObject(); //the reference(pointer/memory address) is stored in the permgen section, the object itself is not.

Static code clocks are used for assigning initial values to static variables. These are also called �static initializers�. 
Static blocks are executed right after static variables are loaded into the memory. 
JVM guarantees that static code blocks are executed before an object created for that class. 

Static Import
We already know that we reference static methods using the class name. For example in Java, 
Math class in java.lang package is full of static methods and we need to invoke these methods using Math.nameOfMethod(). 
Using static import we can invoke them by using method name only. Lets see how it is used:


 */
package com.allstate.core;

import java.util.Random;
import static java.lang.Math.*;

public class UseofStatic {
	
	static int i =1;
	private static int array[];
    private static int length = 10;

    static {
    	System.out.println("In side static block");

        array = new int[length];
        Random rnd = new Random();

        for(int i=0; i<  length; i++)
        array[i] = rnd.nextInt(100);
    }
	
	public static void main(String[] args) {
		
		System.out.println("Number of student in the beginning: " + Student.numberOfStudents);

        // create two student objects
        Student student1 = new Student("Obi-Wan Kenobi", 19, "2010001");
        Student student2 = new Student("Anakin Skywalker", 16, "2010002");

        int num = Student.numberOfStudents;
        System.out.println("Number of students (Using class name): " + num );

        num = student1.numberOfStudents;
        System.out.println("Number of students (Using first object): " + num );

        num = student2.numberOfStudents;
        System.out.println("Number of students (Using second object): " + num );
		
        int numberOfStudents = Student.getNumberOfStudents();
        System.out.println("Number of students: " + numberOfStudents);
        
        System.out.println("Square root 25: " + sqrt(25));
        System.out.println("Log(100): " + log(100));
        System.out.println("Pi: " + PI);
        
	}

	static void checkThis() {

		//this.i = 1; compile time error

	}
	
}
	
	class Student{

	    private String name;        // Object variable
	    private int age;            // Object variable
	    private String studentId;   // Object variable
	    public static int numberOfStudents = 0; // Class variable

	    public Student(String name, int age, String studentId) {

	        this.name= name;
	        this.age= age;
	        this.studentId= studentId;

	        // Increase the number of students whenever an object is created
	        numberOfStudents++;
	    }
	    
	    public static int getNumberOfStudents () {
	        return numberOfStudents ;
	     }
	    
}
