package com.allstate.core;

import java.util.Date;

public class ImmutableClassObject {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ImmutableClass obj = new ImmutableClass("Anuj", "9591943358", "BUFPK5169L", new Date());
		System.out.println(obj.getMobile());
		System.out.println(obj.getName());
		System.out.println(obj.getPancardNumber());
		System.out.println(obj.getMutableDate());
		
		System.out.println(obj.getMutableDate());
		System.out.println(obj.getMutableDate());
		
	}

}
