package com.allstate.core;

/*

Can abstract class have Constructor in Java - Interview Question
Yes, Now if we say we can not create instance of abstract class then why do Java adds constructor in abstract class. 
One of the reason which make sense is,  when any class extend abstract class, constructor of sub class will invoke 
constructor of super class either implicitly or explicitly. This chaining of constructors is one of the reason abstract 
class can have constructors in Java.

*/

public class AbstractClassConstructor {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Server server = new Tomcat("Apache Tomcat");
		server.start();

	}

}

abstract class Server {
	protected final String name;

	public Server(String name) {
		this.name = name;
	}

	public abstract boolean start();

}

class Tomcat extends Server {
	public Tomcat(String name) {
		super(name);
	}

	@Override
	public boolean start() {
		System.out.println(this.name + " started successfully");
		return true;
	}
}
