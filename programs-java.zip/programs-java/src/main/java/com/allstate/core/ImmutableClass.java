package com.allstate.core;

import java.util.Date;

/*
 * 
 * As said earlier, Immutable classes are those class, whose object can not be modified once created, 
 * it means any modification on immutable object will result in another immutable object. 
 * best example to understand immutable and mutable objects are, String and StringBuffer. 


 * How to create Immutable class?

 There are many immutable classes like String, Boolean, Byte, Short, Integer, Long, Float, Double etc.
 In short, all the wrapper classes and String class is immutable. 
 We can also create immutable class by creating final class that have final data members as the example given below:

 */
public final class ImmutableClass {
	
	final private String pancardNumber;
	private final String name;
    private final String mobile;
    private final Date mutableDate;

    
    public ImmutableClass(String name, String mobile, String pancardNumber, Date mutableDate) {
        this.name = name;
        this.mobile = mobile;
        this.pancardNumber = pancardNumber;
        //this.mutableDate = mutableDate; // Do not do this, as date class is mutable, performing this step can make our class to change the state, though data reference varibale.
        //Here date class has setter to change it's state.
        
        this.mutableDate = new Date(mutableDate.getTime());//Always create the new instance for the mutable objects.
    }
  


	public String getPancardNumber() {
		return pancardNumber;
	}
	
	public String getName(){
        return name;
      }
  
    public String getMobile(){
        return mobile;
    }



	public Date getMutableDate() {
		//return mutableDate; // Don;t do this as told above. it will return date to a caller where they can change the state.
		return new Date(mutableDate.getTime());
	}
	

    

}

/*
 * The above class is immutable because: The instance variable of the class is
 * final i.e. we cannot change the value of it after creating an object. 
 * The class is final so we cannot create the subclass. A more sophisticated
 * approach is to make the constructor private and construct instances in
 * factory methods. 
 * Make all fields final and private.
 * There is no setter methods i.e. we have no option to change
 * the value of the instance variable. These points makes this class as
 * immutable.
 */


/*
Benefits of Immutable Classes in Java
1) Immutable objects are by default thread safe, can be shared without synchronization in concurrent environment.
2) Immutable object simplifies development, because its easier to share between multiple threads without external synchronization.

3) Immutable object boost performance of Java application by reducing synchronization in code.

4) Another important benefit of Immutable objects is reusability, you can cache Immutable object and reuse them, much like String literals and Integers.  You can use static factory methods to provide methods like valueOf(), which can return an existing Immutable object from cache, instead of creating a new one.


Apart from above advantages, immutable object has disadvantage of creating garbage as well. 
Since immutable object can not be reused and they are just a use and throw. 
String being a prime example, which can create lot of garbage and can potentially 
slow down application due to heavy garbage collection, but again that's extreme case and if used properly 
Immutable object adds lot of value.

*/

