package com.allstate.test.junit;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class TestClassOne extends TestCase{

	public TestClassOne(String method) {
	    super(method);
	  }

	  public void testAddition() {
	    assertEquals(4, 2 + 2);
	  }

	  public void testSubtraction() {
	    assertEquals(0, 2 - 2);
	  }
	}

	class TestClassTwo extends TestCase {
	  public TestClassTwo(String method) {
	    super(method);
	  }

	  public void testLongRunner() {
	    assertEquals(2300, 0);
	  }

	  public static Test suite() {
	    TestSuite suite = new TestSuite();
	    // Only include short tests
	    suite.addTest(new TestClassTwo("testShortTest"));
	    suite.addTest(new TestClassTwo("testAnotherShortTest"));
	    return suite;
	  }
}
