package com.allstate.fin.the.pairs;

import java.util.HashSet;
import java.util.Set;

public class FindThePairs {

	public static void main(String[] args) {
		
		int[] numbers = { 2, 4, 3, 5, 7, 8, 9 };
		int[] numbersWithDuplicates = { 2, 4, 3, 5, 6, -1, 4, -7, 8, 9 };

		
	
		printPairsUsingSet(numbersWithDuplicates ,2);
		
			
	}

	public static void printPairsUsingSet(int[] numbers, int n) {
		if (numbers.length < 2) {
			return;
		}
		Set set = new HashSet(numbers.length);
		for (int value : numbers) {
			int target = n - value; // 
			//if target number is not in set then add
			if(!set.contains(target)){
				set.add(value); 
				}else {
				System.out.printf("(%d, %d) %n", value, target); 
				} 
			} 
		}

		
	
}
