package com.allstate.collection.test;

import java.util.Map.Entry;
import java.util.TreeMap;

//http://www.programcreek.com/2013/03/hashmap-vs-treemap-vs-hashtable-vs-linkedhashmap
public class TestTreeMap {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	/*	Dog1 d1 = new Dog1("red");
		Dog1 d2 = new Dog1("black");
		Dog1 d3 = new Dog1("white");
		Dog1 d4 = new Dog1("white");*/

		
		Dog1 d1 = new Dog1("red", 30);
		Dog1 d2 = new Dog1("black", 20);
		Dog1 d3 = new Dog1("white", 10);
		Dog1 d4 = new Dog1("white", 10);
		
		TreeMap<Dog1, Integer> treeMap = new TreeMap<Dog1, Integer>();
		treeMap.put(d1, 10);
		treeMap.put(d2, 15); //Exception in thread "main" java.lang.ClassCastException: collection.Dog cannot be cast to java.lang.Comparable
		//Since TreeMaps are sorted by keys, the object for key has to be able to compare with each other, 
		//that's why it has to implement Comparable interface. For example, you use String as key, because String implements Comparable interface.
		
		treeMap.put(d3, 5);
		treeMap.put(d4, 20);

		for (Entry<Dog1, Integer> entry : treeMap.entrySet()) {
			System.out.println(entry.getKey() + " - " + entry.getValue());
		}
	}

}

class Dog1 implements Comparable<Dog1>{
	String color;
	int size;
	Dog1(String c) {
		color = c;
	}
	
	Dog1(String c, int s) {
		color = c;
		size = s;
	}
 
	
	public boolean equals(Object o) {
		return ((Dog1) o).color.equals(this.color);
	}

	public int hashCode() {
		return color.length();
	}

	public String toString() {
		return color + " dog";
	}

	@Override
	public int compareTo(Dog1 o) {
		// TODO Auto-generated method stub
		return  o.size - this.size;
}
}
