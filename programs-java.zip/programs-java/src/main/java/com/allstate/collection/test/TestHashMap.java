package com.allstate.collection.test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class TestHashMap {
	public static void main(String[] args) {
		HashMap<Dog, Integer> hashMap = new HashMap<Dog, Integer>();
		Dog d1 = new Dog("red");
		Dog d2 = new Dog("black");
		Dog d3 = new Dog("white"); // Twice white dog
		Dog d4 = new Dog("white");

		hashMap.put(d1, 10);
		hashMap.put(d2, 15);
		hashMap.put(d3, 5);// white dog will be added once because we overwrite the equals and hascode method.
		hashMap.put(d4, 20);
		hashMap.put(d4, 50); // here we overwrite the key and value because key is the same.

		// print size
		System.out.println(hashMap.size());
		// loop HashMap
		for (Entry<Dog, Integer> entry : hashMap.entrySet()) {
			System.out.println(entry.getKey().toString() + " - "
					+ entry.getValue());
		}
		
		//Frequently Used Methods of Java HashMap
		//1. Loop Through HashMap
		Iterator it = hashMap.entrySet().iterator();
		while (it.hasNext()) {
		    Map.Entry pairs = (Map.Entry)it.next();
		    System.out.println(pairs.getKey() + " = " + pairs.getValue());
		}
		
		//3 . Sort HashMap by Value - use Comparator
		
		
	}
	
	//2.Print HashMap
	public static void printMap(Map mp) {
	    Iterator it = mp.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pairs = (Map.Entry)it.next();
	        System.out.println(pairs.getKey() + " = " + pairs.getValue());
	        it.remove(); // avoids a ConcurrentModificationException
	    }
	}
	
}

class Dog {
	String color;

	Dog(String c) {
		color = c;
	}

	public String toString() {
		return color + " dog";
	}
	
	//By default, the hashCode() and equals() methods implemented in the Object class are used. 
	//The default hashCode() method gives distinct integers for distinct objects, 
	//and the equals() method only returns true when two references refer to the same object. 
	//Now we overwrite the equals and hashcode method to remove the duplicate entry.
	public boolean equals(Object o) {
		return ((Dog) o).color.equals(this.color);
	}
 
	public int hashCode() {
		return color.length();
	}
	
}
