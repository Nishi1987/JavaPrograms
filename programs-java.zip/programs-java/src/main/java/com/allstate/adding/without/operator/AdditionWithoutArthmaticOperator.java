package com.allstate.adding.without.operator;

import java.math.BigInteger;

public class AdditionWithoutArthmaticOperator {
	
	public static void main(String[] args) {
		System.out.println(add(5,8));
	}
	public static int add(int a, int b) {
		BigInteger i = BigInteger.valueOf(a);
		BigInteger j = BigInteger.valueOf(b);
		BigInteger sum = i.add(j);
		return sum.intValue();
	}

}
