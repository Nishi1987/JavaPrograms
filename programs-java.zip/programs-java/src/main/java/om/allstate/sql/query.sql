---###################################################################################################################################################################################################################################
--SQL: Data Types

--Data Type 	                  Syntax 			Explanation (if applicable)

integer 	          integer 

smallint 			 smallint

numeric 			numeric(p,s) 			Where p is a precision value; s is a scale value. For example, numeric(6,2) is a number that has 4 digits before the decimal and 2 digits after the decimal.

decimal 			decimal(p,s) 			Where p is a precision value; s is a scale value.

real 	        real 			        Single-precision		floating point number

double precision		double precision 		Double-precision floating point number

float 			        float(p) 			Where p is a precision value.

character 			char(x) 			Where x is the number of characters to store. This data type is space padded to fill the number of characters specified.

character varying		varchar2(x) 			Where x is the number of characters to store. This data type does NOT space pad.

bit 				bit(x) 				Where x is the number of bits to store.

bit varying 			bit varying(x) 			Where x is the number of bits to store. The length can vary up to x.

date 	date 							Stores year, month, and day values.

time 	time 							Stores the hour, minute, and second values.

timestamp 			timestamp 			Stores year, month, day, hour, minute, and second values.

time with time zone 		time with time zone 		Exactly the same as time, but also stores an offset from UTC of the time specified.

timestamp with time zone 	timestamp with time zone 	Exactly the same as timestamp, but also stores an offset from UTC of the time specified.

year-month interval 						Contains a year value, a month value, or both.

day-time interval 						Contains a day value, an hour value, a minute value,nd/or a second value.

-------#####################################################################################################################################################################


--######### Character / String Functions #######-------

select ascii('T') from dual;
select ascii(34) from dual;

select asciistr('3 B C � �') from dual;

select chr(116) from dual;

select compose('o' || unistr('\0308') ) from dual;
 m
select concat('Tech on', ' the Net') from dual;
select concat('Tech on', concat('Tech on', ' the Net')) from dual;

use test;

select 'Tech on' || ' the Net' from dual;

select convert('A B C D E � � � � �', 'US7ASCII', 'WE8ISO8859P1') from dual;

select decompose('Tr�s bien') from dual;

select dump('Technique', 10) from dual;
select dump('Tech', 1017) from dual;

select initcap('tech on the net') from dual;
select initcap('GEORGE BURNS') from dual;

select instr('Tech on the net', 'e', 1, 1) from dual;

select length('Tech on the Net ') from dual;

select lower('GEORGE BURNS 123   ') from dual;
select upper('george burns 123   ') from dual;

select lpad('212379', 10, '*') from dual;
select rpad('212379', 10, '*') from dual;

select lpad('212379', 10, '*') || '******'  from dual;

select ltrim('123123Tech123', '123') from dual;

select ltrim('xyxzyyyTech', 'xyz') from dual;

select rtrim('xyxzyyyTechxyxyxyxy', 'xyz') from dual;

select replace('123123tech', '123') from dual;

select replace('1231123tech', '123') from dual;

select replace('1231123tech', '1', 'ZZ') from dual;

select soundex('apples') from dual;

select substr('This is a test', 6, 2) from dual;
select substr('This is a test', 6) from dual;
select substr('TechOnTheNet', 1, 4) from dual;
select substr('TechOnTheNet', -3, 3) from dual;
select substr('TechOnTheNet', -8, 2) from dual;


select translate('1tech23', '123', '456') from dual;
select translate('222Hech', '2ech', '3itP') from dual;

select trim('   tech   ') from dual;
select trim(' '  from  '   tech   ') from dual;
select trim(leading '0' from '000123') from dual;
select trim(trailing '1' from 'Tech1') from dual;
select trim(both '1' from '123Tech111') from dual;


select vsize('Tech on the net') from dual;

select bin_to_num(1,1,1,1) from dual;

select * from nex_location where rowid = chartorowid('AAALTRAAGAAAAC3AAA');
select * from nex_location where rowid = 'AAALTRAAGAAAAC3AAA';
select rowid from nex_location;


select to_char(1210.73, '9999.9') from dual;
select to_char(1210.73, '9,999.99') from dual;
select to_char(1210.73, '$9,999.000') from dual;
select to_char(21, '000099') from dual;


select to_date('2003/07/09', 'yyyy/mm/dd') from dual;
select to_date('070903', 'MMDDYY') from dual;
select to_date('20020315', 'yyyymmdd') from dual;

select to_number('1210.73', '9999.99') from dual;

SELECT coalesce( 'anu', 'Anuj', 'Kumar' ) from dual;
SELECT coalesce( null, 'Anuj', 'Kumar' ) from dual;
SELECT coalesce( null, null, 'Kumar' ) from dual;
SELECT coalesce( null, null, null ) from dual;


select decode('3030', 1000, 'IBM',
                      2000, 'Wipro',
                      3000, 'TCS',
                      'No data Found') from dual
                      


select NVL(null,'N/A') from dual;
select NVL2('NotNull', 'Completed', 'n/a') from dual;
select NVL2(null, 'Completed', 'n/a') from dual;


select userenv('LANGUAGE') from dual;
select userenv('SESSIONID') from dual;
select userenv('CLIENT_INFO') from dual;
select userenv('ENTRYID') from dual;
select userenv('TERMINAL') from dual;
select userenv('ISDBA') from dual;
select userenv('LANG') from dual;

select user from dual;
select uid from dual;


select NULLIF(12, 12) from dual;
select NULLIF(12, 42) from dual;

Error --select NULLIF(NULL, 12) from dual;


select table_name,
CASE
    WHEN owner='SYS' THEN 'The owner is SYS'
    WHEN owner='SYSTEM' THEN 'The owner is SYSTEM'
    ELSE 'The owner is another value'
END
from all_tables where table_name like '%NTS_%';






--###  CREATE a table ###---

CREATE TABLE employees
( 	employee_number number(10) 	not null,
  	employee_name 	varchar2(50) 	not null,
  	department_id 	number(10), 	
  	salary 	number(6), 	
  	CONSTRAINT employees_pk PRIMARY KEY (employee_number),
  	CONSTRAINT fk_departments
        FOREIGN KEY (department_id)
        REFERENCES departments(department_id)
); 	


--A foreign key with a cascade delete means that if a record in the parent table is deleted, then the corresponding records in the child table with automatically be deleted. This is called a cascade delete.

--Parent table 
CREATE TABLE EX_SUPPLIER
( supplier_id 	numeric(10) 	not null,
	supplier_name 	varchar2(50) 	not null,
	contact_name 	varchar2(50), 	
	CONSTRAINT supplier_pk PRIMARY KEY (supplier_id)
);


--child table
CREATE TABLE products
( 	product_id 	numeric(10) 	not null,
	supplier_id 	numeric(10) 	not null,
	CONSTRAINT fk_supplier
	  FOREIGN KEY (supplier_id)
	 REFERENCES supplier(supplier_id)
	 ON DELETE CASCADE
);

CREATE TABLE EX_PRODUCT (
PRODUCT_ID NUMERIC(10) NOT NULL,
SUPPLIER_ID_PRODUCT NUMERIC(10) NOT NULL,
CONSTRAINT FK_EX_SUPPLIER FOREIGN KEY (SUPPLIER_ID_PRODUCT) REFERENCES EX_SUPPLIER(SUPPLIER_ID) ON DELETE CASCADE);

DESC EX_PRODUCT;
--A foreign key with a "set null on delete" means that if a record in the parent table is deleted, then the corresponding records in the child table will have the foreign key fields set to null. The records in the child table will not be deleted.

CREATE TABLE products
( 	product_id 	numeric(10) 	not null,
	supplier_id 	numeric(10), 	
	CONSTRAINT fk_supplier
	  FOREIGN KEY (supplier_id)
	 REFERENCES supplier(supplier_id)
	 ON DELETE SET NULL
);

--The syntax for dropping a foreign key is:

ALTER TABLE table_name
drop CONSTRAINT constraint_name;


ALTER TABLE products
drop CONSTRAINT fk_supplier;

--Disable and enable foreign keys

ALTER TABLE products
disable CONSTRAINT fk_supplier;


ALTER TABLE products
enable CONSTRAINT fk_supplier;




---------Unique Constraints--------

--A unique constraint is a single field or combination of fields that uniquely defines a record. Some of the fields can contain null values as long as the combination of values is unique.

CREATE TABLE supplier
( 	supplier_id 	numeric(10) 	not null,
	supplier_name 	varchar2(50) 	not null,
	contact_name 	varchar2(50), 	
	CONSTRAINT supplier_unique UNIQUE (supplier_id, supplier_name)
);



ALTER TABLE supplier
add CONSTRAINT supplier_unique UNIQUE (supplier_id);


ALTER TABLE supplier
drop CONSTRAINT supplier_unique;


ALTER TABLE supplier
disable CONSTRAINT supplier_unique;

ALTER TABLE supplier
enable CONSTRAINT supplier_unique;


--------Oracle/PLSQL: Check Constraints------

--A check constraint allows you to specify a condition on each row in a table.

--Note:
--
--    A check constraint can NOT be defined on a VIEW.
--    The check constraint defined on a table must refer to only columns in that table. It can not refer to columns in other tables.
--    A check constraint can NOT include a SUBQUERY.
--
--A check constraint can be defined in either a CREATE TABLE statement or an ALTER TABLE statement.


CREATE TABLE suppliers
( 	supplier_id 	numeric(4), 	
	supplier_name 	varchar2(50), 	
	CONSTRAINT check_supplier_id
	CHECK (supplier_id BETWEEN 100 and 9999)
);


CREATE TABLE suppliers
( 	supplier_id 	numeric(4), 	
	supplier_name 	varchar2(50), 	
	CONSTRAINT check_supplier_name
	CHECK (supplier_name = upper(supplier_name))
);


ALTER TABLE suppliers
add CONSTRAINT check_supplier_name
   CHECK (supplier_name IN ('IBM', 'Microsoft', 'NVIDIA'));
   

ALTER TABLE suppliers
drop CONSTRAINT check_supplier_id;



ALTER TABLE suppliers
enable CONSTRAINT check_supplier_id;

ALTER TABLE suppliers
disable CONSTRAINT check_supplier_id;




----#### CREATE a table from another table####---

--Syntax #1 - Copying all columns from another table

CREATE TABLE new_table 
    AS (SELECT * 
            FROM old_table);

CREATE TABLE suppliers
  AS (SELECT *
         FROM companies
         WHERE id > 1000);
         
--Syntax #2 - Copying selected columns from another table


CREATE TABLE suppliers
  AS (SELECT id, address, city, state, zip
          FROM companies
          WHERE id > 1000);


---Syntax #3 - Copying selected columns from multiple tables

CREATE TABLE suppliers
  AS (SELECT companies.id, companies.address, categories.cat_type
          FROM companies, categories
          WHERE companies.id = categories.id
          AND companies.id > 1000);
          

---How can I create a table from another table without copying any values from the old table?

CREATE TABLE suppliers
  AS (SELECT * FROM companies WHERE 1=2);
  


--#######SQL: ALTER TABLE Statement##########---


----Renaming a table

ALTER TABLE suppliers
 RENAME TO vendors;
 
 --Adding column(s) to a table
 
 ALTER TABLE supplier
 ADD supplier_name  varchar2(50);
 
 
 ALTER TABLE supplier
ADD ( 	supplier_name 	varchar2(50),
  	city 	varchar2(45) );
        

---Modifying column(s) in a table

ALTER TABLE supplier
 MODIFY supplier_name   varchar2(100)     not null;
 
 ALTER TABLE supplier
MODIFY ( 	supplier_name 	varchar2(100) 	not null,
	city 	varchar2(75) 	  	);

---Drop column(s) in a table

ALTER TABLE supplier
 DROP COLUMN supplier_name;
 
 ---Rename column(s) in a table(NEW in Oracle 9i Release 2)
ALTER TABLE supplier
 RENAME COLUMN supplier_name to sname;
 
 
 ---#####SQL: DROP TABLE Statement#####--
 
 DROP TABLE supplier;
 
 ----#####  SQL: Global Temporary tables ####----
 
 CREATE GLOBAL TEMPORARY TABLE supplier
( 	supplier_id 	numeric(10) 	not null,
	supplier_name 	varchar2(50) 	not null,
	contact_name 	varchar2(50) 	
) 	
 
 
 
 
  
  

---### SQL: VIEWS ---####
--A view is, in essence, a virtual table. It does not physically exist. Rather, it is created by a query joining one or more tables.

CREATE VIEW sup_orders AS
SELECT suppliers.supplier_id, orders.quantity, orders.price
FROM suppliers, orders
WHERE suppliers.supplier_id = orders.supplier_id
and suppliers.supplier_name = 'IBM';

--This would create a virtual table based on the result set of the select statement. You can now query the view as follows:

    SELECT *
    FROM sup_orders;
    
    
--### Updating a VIEW --##

CREATE or REPLACE VIEW sup_orders AS
SELECT suppliers.supplier_id, orders.quantity, orders.price
FROM suppliers, orders
WHERE suppliers.supplier_id = orders.supplier_id
and suppliers.supplier_name = 'Microsoft';


---Dropping a VIEW

DROP VIEW sup_orders;

--  Question: Can you update the data in a view?
--
--Answer: A view is created by joining one or more tables. When you update record(s) in a view, it updates the records in the underlying tables that make up the view.
--
--So, yes, you can update the data in a view providing you have the proper privileges to the underlying tables.
--
--Question: Does the view exist if the table is dropped from the database?
--
--Answer: Yes, in Oracle, the view continues to exist even after one of the tables (that the view is based on) is dropped from the database. However, if you try to query the view after the table has been dropped, you will receive a message indicating that the view has errors.
--
--If you recreate the table (that you had dropped), the view will again be fine.


--######SQL: LIKE Condition -----########
  
  SELECT Count(*) FROM all_tables WHERE table_name like '%NEX%';
  
-------GROUP BY Clause



SELECT column1, column2, ... column_n, aggregate_function (expression)
FROM tables
WHERE predicates
GROUP BY column1, column2, ... column_n;

aggregate_function can be a function such as SUM, COUNT, MIN, or MAX.


----####  Joins ----#####


---Simple join 


SELECT suppliers.supplier_id, suppliers.supplier_name, orders.order_date
FROM suppliers, orders
WHERE suppliers.supplier_id = orders.supplier_id;


----Outer Join----



select suppliers.supplier_id, suppliers.supplier_name, orders.order_date
from suppliers, orders
where orders.supplier_id(+) = suppliers.supplier_id




select suppliers.supplier_id, suppliers.supplier_name, orders.order_date
from suppliers, orders
where suppliers.supplier_id = orders.supplier_id(+);


----ORDER BY Clause

SELECT columns
FROM tables
WHERE predicates
ORDER BY column ASC/DESC;

ASC indicates ascending order. (default)
DESC indicates descending order.


You can also sort by relative position in the result set, where the first field in the result set is 1. The next field is 2, and so on.

    SELECT supplier_city
    FROM suppliers
    WHERE supplier_name = 'IBM'
    ORDER BY 1 DESC


----HAVING Clause


SELECT department, SUM(sales) as "Total sales"
FROM order_details
GROUP BY department
HAVING SUM(sales) > 1000;


---EXISTS Condition

SELECT columns
FROM tables
WHERE EXISTS/not exists ( subquery );




SELECT * FROM suppliers
WHERE EXISTS(select * from orders  where suppliers.supplier_id = orders.supplier_id);
    
  
DELETE FROM suppliers
WHERE EXISTS(select * from orders where suppliers.supplier_id = orders.supplier_id);
    
    
    
    
UPDATE suppliers 	
SET supplier_name =( SELECT customers.name FROM customers WHERE customers.customer_id = suppliers.supplier_id)
WHERE EXISTS( SELECT customers.name FROM customers WHERE customers.customer_id = suppliers.supplier_id);
    
    
    
    
    
INSERT INTO suppliers  (supplier_id, supplier_name)
SELECT account_no, name FROM suppliers
WHERE exists (select * from orders Where suppliers.supplier_id = orders.supplier_id);


-----BETWEEN Condition


SELECT * 
FROM suppliers
WHERE supplier_id between 5000 AND 5010;



SELECT *
FROM suppliers
WHERE supplier_id not between 5000 and 5500;


-----In Condition

SELECT *
FROM suppliers
WHERE supplier_name in ( 'IBM', 'Hewlett Packard', 'Microsoft');


SELECT *
FROM suppliers
WHERE supplier_name not in ( 'IBM', 'Hewlett Packard', 'Microsoft');


----Union Query ----------

The UNION query allows you to combine the result sets of 2 or more "select" queries. It removes duplicate rows between the various "select" statements.

Each SQL statement within the UNION query must have the same number of fields in the result sets with similar data types.




select field1, field2, . field_n
from tables
UNION
select field1, field2, . field_n
from tables;




The UNION ALL query allows you to combine the result sets of 2 or more "select" queries. It returns all rows (even if the row exists in more than one of the "select" statements).

Each SQL statement within the UNION ALL query must have the same number of fields in the result sets with similar data types.


select field1, field2, . field_n
from tables
UNION ALL
select field1, field2, . field_n
from tables;


--------------INTERSECT query-------------------

The INTERSECT query allows you to return the results of 2 or more "select" queries. However, it only returns the rows selected by all queries. If a record exists in one query and not in the other, it will be omitted from the INTERSECT results.

Each SQL statement within the INTERSECT query must have the same number of fields in the result sets with similar data types.

The syntax for an INTERSECT query is:

select field1, field2, . field_n
from tables
INTERSECT
select field1, field2, . field_n
from tables;



-------MINUS Query

The MINUS query returns all rows in the first query that are not returned in the second query.

Each SQL statement within the MINUS query must have the same number of fields in the result sets with similar data types.

The syntax for an MINUS query is:

select field1, field2, . field_n
from tables
MINUS
select field1, field2, . field_n
from tables;



-----DISTINCT -------


SELECT DISTINCT columns
FROM tables
WHERE predicates;


------INSERT Statement----------

INSERT INTO suppliers
(supplier_id, supplier_name)
VALUES
(24553, 'IBM');



INSERT INTO suppliers
(supplier_id, supplier_name)
SELECT account_no, name
FROM customers
WHERE city = 'Newark';




----How can I insert multiple rows of explicit data in one SQL command in Oracle?

INSERT ALL
   INTO suppliers (supplier_id, supplier_name) VALUES (1000, 'IBM')
   INTO suppliers (supplier_id, supplier_name) VALUES (2000, 'Microsoft')
   INTO suppliers (supplier_id, supplier_name) VALUES (3000, 'Google')
SELECT * FROM dual;




-----UPDATE Statement-----

UPDATE suppliers
SET name = 'HP'
WHERE name = 'IBM';



UPDATE suppliers
SET name = 'Apple', product = 'iPhone'
WHERE name = 'Rim';



------Delete --------

DELETE FROM suppliers
WHERE supplier_name = 'IBM';




------------###########################################------------------


---Oracle/PLSQL: Sequences (Autonumber)


CREATE SEQUENCE sequence_name
    MINVALUE value
    MAXVALUE value
    START WITH value
    INCREMENT BY value
    CACHE/NOCACHE value;
    
    
    

CREATE SEQUENCE supplier_seq
    MINVALUE 1
    MAXVALUE 999999999999999999999999999
    START WITH 1
    INCREMENT BY 1
    CACHE 20;
    

CREATE SEQUENCE EX_PRODUCT_SEQ
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
CACHE 20;

    
This would create a sequence object called supplier_seq. The first sequence number that it would use is 1 and each subsequent number would increment by 1 (ie: 2,3,4,...}. It will cache up to 20 values for performance.

If you omit the MAXVALUE option, your sequence will automatically default to:

MAXVALUE 999999999999999999999999999

supplier_seq.nextval

INSERT INTO suppliers
(supplier_id, supplier_name)
VALUES
(supplier_seq.nextval, 'Kraft Foods');



For example, if the last value used by the Oracle sequence was 100 and you would like to reset the sequence to serve 225 as the next value. You would execute the following commands.

alter sequence seq_name
increment by 124;

select seq_name.nextval from dual;



------------Oracle/PLSQL: Roles---------------


---A role is a set or group of privileges that can be granted to users or another role. This is a great way for database administrators to save time and effort.


---To create a role, you must have CREATE ROLE system privileges.

--The syntax for creating a role is:

CREATE ROLE role_name
[ NOT IDENTIFIED |
IDENTIFIED {BY password | USING [schema.] package | EXTERNALLY | GLOBALLY } ;





CREATE ROLE test_role;

--This first example creates a role called test_role.

    CREATE ROLE test_role
    IDENTIFIED BY test123;

--This second example creates the same role called test_role, but now it is password protected with the password of test123.


--The syntax for granting privileges on a table is:
grant privileges on object to role_name


--For example, if you wanted to grant select, insert, update, and delete privileges on a table called suppliers to a role named test_role, you would execute the following statement:
grant select, insert, update, delete on suppliers to test_role;

--You can also use the all keyword to indicate that you wish all permissions to be granted. For example:
grant all on suppliers to test_role;





---Revoke Privileges (on Tables) to Roles-


revoke privileges on object from role_name;

revoke delete on suppliers from test_role;

revoke all on suppliers from test_role;

--------------Grant Privileges (on Functions/Procedures) to Roles-----------

--When dealing with functions and procedures, you can grant roles the ability to execute these functions and procedures. The Execute privilege is explained below:


--Execute : Ability to compile the function/procedure. and Ability to execute the function/procedure directly.

--The syntax for granting execute privileges on a function/procedure is:

    grant execute on object to role_name;

--For example, if you had a function called Find_Value and you wanted to grant execute access to the role named test_role, you would execute the following statement:

    grant execute on Find_Value to test_role;
    
    revoke execute on Find_Value from test_role;
    


---################   Granting the Role to a User ###########-----

--Now, that you've created the role and assigned the privileges to the role, you'll need to grant the role to specific users.

GRANT role_name TO user_name;


This example would grant the role called test_role to the user named smithj.
   GRANT test_role to smithj;
   
   
   
  -----#######The SET ROLE statement---------#######
  
  The SET ROLE statement allows you to enable or disable a role for a current session.
  
  SET ROLE test_role IDENTIFIED BY test123;
  
  
  

    ALTER USER smithj
    DEFAULT ROLE
    test_role;

This example would set the role called test_role as a DEFAULT role for the user named smithj.

    ALTER USER smithj
    DEFAULT ROLE
    ALL;

This example would set all roles assigned to smithj as DEFAULT.

    ALTER USER smithj
    DEFAULT ROLE
    ALL EXCEPT test_role;

This example would set all roles assigned to smithj as DEFAULT, except for the role called test_role.



###-----Dropping a Role---####

It is also possible to drop a role. The syntax for dropping a role is:

DROP ROLE role_name;
For Example

    DROP ROLE test_role;

This drop statement would drop the role called test_role that we defined earlier.


--------------------###########################################################--------------

---Oracle/PLSQL: Change a user's password in Oracle---

alter user user_name identified by new_password;

alter user smithj identified by autumn;






----------------------------------###################################Questions#######################################----------------------------------------------------

--sql QUERY TO FIND THE -nth-highest-salary-sql


/*
The salary in the first row of the Employee table is 200. Because the subquery is correlated to the outer query through the alias Emp1, 
it means that when the first row is processed, the query will essentially look like this � note that all we did is replace Emp1.Salary with the value of 200:
50000
2500
2000
700
600
500
250
200
100
SELECT COUNT(DISTINCT PRS_EP075_AMT) 
FROM XATESTSTAL1.XAT_PROP_END_REF_SPJ WHERE 250 <= PRS_EP075_AMT;
*/

-- N'TH HIGHTEST 
SELECT DISTINCT PRS_EP075_AMT, PRS_STATE_CD
FROM XATESTSTAL1.XAT_PROP_END_REF_SPJ E WHERE
6 =(SELECT COUNT(DISTINCT PRS_EP075_AMT) 
FROM XATESTSTAL1.XAT_PROP_END_REF_SPJ WHERE E.PRS_EP075_AMT <= PRS_EP075_AMT);


--SECOND
SELECT MAX(PRS_EP075_AMT) FROM XATESTSTAL1.XAT_PROP_END_REF_SPJ
WHERE PRS_EP075_AMT < (SELECT MAX(PRS_EP075_AMT) FROM XATESTSTAL1.XAT_PROP_END_REF_SPJ )




/*
In SQL, what�s the difference between an inner and outer join?

Joins are used to combine the data from two tables, with the result being a new, temporary table. The temporary table is created based on column(s) that the two tables 
share, which represent meaningful column(s) of comparison. The goal is to extract meaningful data from the resulting temporary table. 
Joins are performed based on something called a predicate, which specifies the condition to use in order to perform a join. 
A join can be either an inner join or an outer join, depending on how one wants the resulting table to look.

It is best to illustrate the differences between inner and outer joins by use of an example. Here we have 2 tables that we will use for our example:

Employee
EmpID	 EmpName
13	 Jason
8	 Alex
3	 Ram
17	 Babu
25	 Johnson

Location
EmpID	 EmpLoc
13	 San Jose
8	 Los Angeles
3	 Pune, India
17	 Chennai, India
39	 Bangalore, India


It�s important to note that the very last row in the Employee table does not exist in the Employee Location table. Also, the very last row in the Employee Location table 
does not exist in the Employee table. These facts will prove to be significant in the discussion that follows.

Outer Joins -----

Let�s start the explanation with outer joins. Outer joins can be be further divided into left outer joins, right outer joins, and full outer joins. 
Here is what the SQL for a left outer join would look like, using the tables above:


*/



select * from employee left outer join location 
on employee.empID = location.empID;

select * from employee left join location 
on employee.empID = location.empID;



A left outer join retains all of the rows of the left table, regardless of whether there is a row that matches on the right table. The SQL above will give us the result set shown below.
Employee.EmpID	 Employee.EmpName	 Location.EmpID	 Location.EmpLoc
13	 Jason	 13	 San Jose
8	 Alex	 8	 Los Angeles
3	 Ram	 3	 Pune, India
17	 Babu	 17	 Chennai, India
25	 Johnson	 NULL	 NULL


A right outer join is pretty much the same thing as a left outer join, except that the rows that are retained are from the right table. This is what the SQL looks like:

select * from employee right outer join location 
on employee.empID = location.empID;

// taking out the "outer", this also works:

select * from employee right join location 
on employee.empID = location.empID;


Using the tables presented above, we can show what the result set of a right outer join would look like:

Employee.EmpID	 Employee.EmpName	 Location.EmpID	 Location.EmpLoc
13	 Jason	 13	 San Jose
8	 Alex	 8	 Los Angeles
3	 Ram	 3	 Pune, India
17	 Babu	 17	 Chennai, India
NULL	 NULL	 39	 Bangalore, India



Inner Joins

Now that we�ve gone over outer joins, we can contrast those with the inner join. The difference between an inner join and an outer join is that an inner join will 
return only the rows that actually match based on the join predicate. Once again, this is best illustrated via an example. 
Here�s what the SQL for an inner join will look like:

select * from employee inner join location on 
employee.empID = location.empID
This can also be written as:

select * from employee, location
where employee.empID = location.empID
              
Now, here is what the result of running that SQL would look like:

Employee.EmpID	 Employee.EmpName	 Location.EmpID	 Location.EmpLoc
13	 Jason	 13	 San Jose
8	 Alex	 8	 Los Angeles
3	 Ram	 3	 Pune, India
17	 Babu	 17	 Chennai, India




In SQL, what are the differences between primary, foreign, and unique keys?
The one thing that primary, unique, and foreign keys all have in common is the fact that each type of key can consist of more than just one column from a given table. In other words, foreign, primary, and unique keys are not restricted to having just one column from a given table � each type of key can cover multiple columns. So, that is one feature that all the different types of keys share � they can each be comprised of more than just one column, which is something that many people in software are not aware of.



What is the point of having a foreign key?
Foreign keys are used to reference unique columns in another table. So, for example, a foreign key can be defined on one table A, and it can reference some unique column(s) in another table B. Why would you want a foreign key? Well, whenever it makes sense to have a relationship between columns in two different tables.


Can a table have multiple unique, foreign, and/or primary keys?
A table can have multiple unique and foreign keys. However, a table can have only one primary key.

Can a unique key have NULL values? Can a primary key have NULL values?
Unique key columns are allowed to hold NULL values. The values in a primary key column, however, can never be NULL.

Can a foreign key reference a non-primary key?
Yes, a foreign key can actually reference a key that is not the primary key of a table. But, a foreign key must reference a unique key.

Can a foreign key contain null values?
Yes, a foreign key can hold NULL values. Because foreign keys can reference unique, non-primary keys � which can hold NULL values � this means that foreign keys can themselves hold NULL values as well.

Some other differences between foreign, primary, and unique keys
While unique and primary keys both enforce uniqueness on the column(s) of one table, foreign keys define a relationship between two tables. A foreign key identifies a column or group of columns in one (referencing) table that refers to a column or group of columns in another (referenced) table � in our example above, the Employee table is the referenced table and the Employee Salary table is the referencing table.



What is a self join? Explain it with an example and tutorial.

Self Join SQL Example

SELECT e1.employee_name
FROM employee e1, employee e2
WHERE e1.employee_location = e2.employee_location
AND e2.employee_name="Joe";
This query will return the names Joe and Jack � since Jack is the only other person who lives in New York like Joe.

Generally, queries that refer to the same table can be greatly simplified by re-writing the queries as self joins. And, there is definitely a performance benefit for this as well.

What does a self join look like?
http://www.programmerinterview.com/index.php/database-sql/what-is-a-self-join/ 
It will help tremendously to actually visualize the actual results of a self join internally. Remember that a self join is just like any other join, where the two tables are merged into one temporary table. First off, you should visualize that we have two separate copies of the employee table, which are given aliases of e1 and e2. These copies would simply look like this � note that we shortened the column names from employee_name and employee_location to just Name and Location for convenience:

e1	
Name	Location
Joe	 New York
Sunil	 India
Alex	 Russia
Albert	 Canada
Jack	 New York

e2
Name	Location
Joe	 New York
Sunil	 India
Alex	 Russia
Albert	 Canada
Jack	 New York
And the final results of running the self join query above � the actual joined table � would look like this:

e1.employee_name	e1.employee_location	e2.employee_name	e2.employee_location
Joe	New York	Joe	New York
Jack	New York	Joe	New York
Self joins versus inner joins

Are self joins and inner joins the same? You might be wondering if all self joins are also inner joins. After all, in our example above our self join uses an inner join because only the rows that match based on the join predicate are returned � non-matching rows are not returned. Well, it turns out that a self join and inner join are completely different concepts. A self join could just as well be an outer join or an inner join � it just depends on how the query is written. We could easily change the query we used above to do a LEFT OUTER JOIN � while the query still remains a self join � but that wouldn�t give us the results we want in our example. So, we use an implied inner join instead because that gives us the correct results. Remember that a query is a self join as long as the two tables being joined are exactly the same table, but whether it�s an inner join or outer join depends on what is specified in the SQL. And, inner/outer joins are separate concepts entirely from a self join.

Self joins manager employee example


The most commonly used example for self joins is the classic employee manager table. The table is called Employee, but holds all employees � including their managers. Every employee has an ID, and there is also a column for the manager ID. So, for example, let�s say we have a table that looks like this � and we call it Employee:

EmployeeID	Name	ManagerID
1	Sam	10
2	Harry	4
4	Manager	NULL
10	AnotherManager	NULL
Notice that in the table above there are two managers, conveniently named �Manager� and �AnotherManager�. And, those managers don�t have managers of their own � as noted by the NULL value in their Manager column.

Now, given the table above, how can we return results that will show each employee�s name, and his/her manager�s name in nicely arranged results � with the employee in one column and his/her manager�s name in the other column. Well, it turns out we can use a self join to do this. Try to come up with the SQL on your own before reading our answer.

Self join manager employee answer

In order to come up with a correct answer for this problem, our goal should be to perform a self join that will have both the employee information and manager information in one row. First off, since we are doing a self join, it helps to visualize the one table as two tables � let�s give them aliases of e1 and e2. Now, with that in mind, we want the employee�s information on one side of the joined table and the manager�s information on the other side of the joined table. So, let�s just say that we want e1 to hold the employee information and e2 to hold the corresponding manager�s information. What should our join predicate be in that case?

Well, the join predicate should look like �ON e1.ManagerID = e2.EmployeeID� � this basically says that we should join the two tables (a self join) based on the condition that the manager ID in e1 is equal to the employee ID in e2. In other words, an employee�s manager in e1 should have the manager�s information in e2. An illustration will help clarify this. Suppose we use that predicate and just select everything after we join the tables. So, our SQL would look like this:

SELECT *
FROM Employee e1
INNER JOIN Employee e2
ON e1.ManagerID = e2.EmployeeID
The results of running the query above would look like this:

e1.EmployeeID	e1.Name	e1.ManagerID	e2.EmployeeID	e2.Name	e2.ManagerID
1	Sam	10	10	AnotherManager	NULL
2	Harry	4	4	Manager	NULL
Note that there are only 2 rows returned � this is because an inner join is performed, which means that only when there is a match between employee ID�s and manager ID�s will there be a result returned. And since there are 2 people without managers (who have a manager ID of NULL), they will not be returned as part of table e1, because no employees have a matching ID of NULL.

Now, remember that we only want to return the names of the employee and corresponding manager as a pair. So, we can fine-tune the SQL as follows:

SELECT e1.Name, e2.Name
FROM Employee e1
INNER JOIN Employee e2
ON e1.ManagerID = e2.EmployeeID
Running the SQL above would return:

Sam    AnotherManager
Harry  Manager

















