package com.allstate.sample.employee.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.allstate.sample.employee.dao.EmployeeDAO;
import com.allstate.sample.employee.dao.model.Employee;
import com.allstate.sample.employee.service.EmployeeService;
import com.allstate.sample.employee.service.dto.EmployeeDTO;

/**
 * Employee Service Implementation
 * 
 * @author rcho3
 *
 */
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeDAO employeeDao;
	
	/** {@inheritDoc} */
	@Override
	public List<EmployeeDTO> getEmployees() {
		List<EmployeeDTO> myEmployeeList = new ArrayList<>();
		List<Employee> employeeList =  employeeDao.findAll();
		for(Employee employee : employeeList) {
			EmployeeDTO employeeDTO = mapEmployeeDTO(employee);
			myEmployeeList.add(employeeDTO);
		}
		
		return myEmployeeList;
	}

	/** {@inheritDoc} */
	@Override
	public EmployeeDTO getEmployeeById(long id) {
		Employee employee = employeeDao.findById(id);
		return mapEmployeeDTO(employee);
	}
	
	/**
	 * Returns {@link EmployeeDTO} 
	 * @param employee
	 * @return
	 */
	private EmployeeDTO mapEmployeeDTO(Employee employee) {
		EmployeeDTO employeeDTO = new EmployeeDTO();
		employeeDTO.setId(employee.getId());
		employeeDTO.setFirstName(employee.getFirstName());
		employeeDTO.setLastName(employee.getLastName());
		employeeDTO.setDepartment(employee.getDepartment());
		
		return employeeDTO;
	}

}
