package com.allstate.sample;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.util.StringUtils;

import com.allstate.sample.employee.service.EmployeeService;
import com.allstate.sample.employee.service.dto.EmployeeDTO;

/**
 * Class with main method to run the app
 * @author rcho3
 *
 */
public class SampleAppXMLRunner {
	
	/** logger */
	private static final Logger LOG = LoggerFactory.getLogger(SampleAppXMLRunner.class);
	private static final String[] CONFIG_LOCATIONS = { "config/application-context.xml" };
	
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(CONFIG_LOCATIONS);
		EmployeeService myEmployeeService = context.getBean("employeeService", EmployeeService.class);
		List<EmployeeDTO> employeeList = myEmployeeService.getEmployees();
		//Using Stream API
		employeeList.stream().forEach(employee -> LOG.info("{} - {} {}", employee.getId(), employee.getFirstName(), employee.getLastName()));
		
		//Close application context
		((ClassPathXmlApplicationContext)context).close();
	}
}
