package com.allstate.sample.employee.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import com.allstate.sample.employee.dao.EmployeeDAO;
import com.allstate.sample.employee.dao.model.Employee;

/**
 * Employee Repository
 * 
 * @author rcho3
 *
 */
public class EmployeeDAOImpl implements EmployeeDAO {

	/** logger */
	private static final Logger LOG = LoggerFactory.getLogger(EmployeeDAOImpl.class);

	private JdbcTemplate jdbcTemplate;
	private SimpleJdbcInsert simpleJdbcInsert;

	@Autowired
	public void setJdbcTemplate(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
		this.simpleJdbcInsert = new SimpleJdbcInsert(dataSource)
									.withTableName("employees");
	}

	/** {@inheritDoc} */
	@Override
	public List<Employee> findAll() {
		LOG.info("Getting employees from database...");
		return jdbcTemplate.query("select id,first_name,last_name,department from employees",
				new RowMapper<Employee>() {
					public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
						return mapEmployee(rs);
					}
				});
	}
	
	/** {@inheritDoc} */
	@Override
	public Employee findById(long id) {
		return jdbcTemplate.queryForObject("select id,first_name,last_name,department from employees where id = ?",
				new Object[] { id }, new RowMapper<Employee>() {
					public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
						return mapEmployee(rs);
					}
				});
	}
	
	/** {@inheritDoc} */
	@Override
	public long add(Employee employee) {
		Map<String, Object> parameters = new HashMap<String, Object>(2);
		parameters.put("id", employee.getId());
		parameters.put("first_name", employee.getFirstName());
        parameters.put("last_name", employee.getLastName());
        parameters.put("department", employee.getDepartment());
        
		return simpleJdbcInsert.execute(parameters);
	}
	
	/**
	 * Extracts row details from {@link ResultSet}
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Employee mapEmployee(ResultSet rs) throws SQLException {
		Employee employee = new Employee();
		employee.setId(rs.getLong("id"));
		employee.setFirstName(rs.getString("first_name"));
		employee.setLastName(rs.getString("last_name"));
		employee.setDepartment(rs.getString("department"));

		return employee;
	}

}
