package com.allstate.sample.employee.dao;

import java.util.List;

import com.allstate.sample.employee.dao.model.Employee;

/**
 * Employee DAO Interface 
 * @author rcho3
 *
 */
public interface EmployeeDAO {
	
	/**
	 * Returns all the employees
	 * @return
	 */
	public List<Employee> findAll();
	
	/**
	 * Returns employee by given id
	 * @param id
	 * @return
	 */
	public Employee findById(long id);
	
	/**
	 * Insert employee to database
	 * @param employee
	 * @return
	 */
	public long add(Employee employee);
}
