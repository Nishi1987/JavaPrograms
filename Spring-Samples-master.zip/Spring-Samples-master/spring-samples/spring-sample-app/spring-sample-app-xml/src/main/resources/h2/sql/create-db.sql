CREATE TABLE employees (
  id         INTEGER PRIMARY KEY,
  first_name VARCHAR(30),
  last_name  VARCHAR(30),
  department VARCHAR(100)
);