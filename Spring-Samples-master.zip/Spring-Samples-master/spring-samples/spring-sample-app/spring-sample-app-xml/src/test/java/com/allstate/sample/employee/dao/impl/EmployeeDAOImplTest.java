package com.allstate.sample.employee.dao.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.allstate.sample.employee.dao.EmployeeDAO;
import com.allstate.sample.employee.dao.model.Employee;

@ContextConfiguration("/config/application-context.xml")
@RunWith(SpringRunner.class)
@Transactional
@Rollback(true)
public class EmployeeDAOImplTest {
	
	private static EmbeddedDatabase embeddedDatabase;
	
	@Autowired
	private EmployeeDAO employeeDAO;
	
	@BeforeClass
    public static void setUp() {
		embeddedDatabase = new EmbeddedDatabaseBuilder()
    		.setType(EmbeddedDatabaseType.H2)
    		.setName("spring-db")
    		.addScript("/h2/sql/create-db.sql")
    		.addScript("/h2/sql/insert-db.sql")
    		.build();
		
    }
	
	@AfterClass
	public static void tearDown() {
		embeddedDatabase.shutdown();
	}
	
	@Test
	public void contextLoads() {
		assertNotNull(employeeDAO);
	}
	
	@Test
	public void testFindAll() {
		List<Employee> employeeList = employeeDAO.findAll();
		
		assertNotNull(employeeList);
		assertTrue(employeeList.size() > 0);
		assertEquals("Rikash", employeeList.get(0).getFirstName());
	}
	
	@Test
	public void testFindById() {
		Employee employee = employeeDAO.findById(1);
		
		assertNotNull(employee);
		assertEquals("Rikash", employee.getFirstName());
		assertEquals("Choudhury", employee.getLastName());
		assertEquals("Product Technology", employee.getDepartment());
	}
	
	@Test
	public void testAdd() {
		Employee employee = new Employee();
		employee.setId(2);
		employee.setFirstName("Himalay");
		employee.setLastName("Rathod");
		employee.setDepartment("Product Technology");
		
		assertEquals(1, employeeDAO.add(employee));
	}
}
