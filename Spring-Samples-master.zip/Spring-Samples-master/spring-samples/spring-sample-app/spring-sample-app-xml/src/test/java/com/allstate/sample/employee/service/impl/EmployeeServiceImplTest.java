package com.allstate.sample.employee.service.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.allstate.sample.employee.service.EmployeeService;
import com.allstate.sample.employee.service.dto.EmployeeDTO;

@ContextConfiguration("/config/application-context-test.xml")
@RunWith(SpringRunner.class)
public class EmployeeServiceImplTest {
	
	@Autowired
	private EmployeeService employeeService;
	
	@Test
	public void contextLoads() {
		assertNotNull(employeeService);
	}
	
	@Test
	public void testGetEmployees() {
		List<EmployeeDTO> employeeList = employeeService.getEmployees();
		assertNotNull(employeeList);
		assertTrue(employeeList.size() > 0);
		assertEquals("Alex", employeeList.get(0).getFirstName());
	}
	
	@Test
	public void testGetEmployeeById() {
		EmployeeDTO employeeDTO = employeeService.getEmployeeById(1);
		assertNotNull(employeeDTO);
		assertEquals("Alex", employeeDTO.getFirstName());
		assertEquals("Harmensen", employeeDTO.getLastName());
		assertEquals("Product Technology", employeeDTO.getDepartment());
	}
}
