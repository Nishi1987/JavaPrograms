package com.allstate.sample.employee.dao.stub.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.allstate.sample.employee.dao.EmployeeDAO;
import com.allstate.sample.employee.dao.model.Employee;

/**
 * Stub implementation of Employee DAO for unit tests
 * @author rcho3
 *
 */
public class EmployeeDAOStubImpl implements EmployeeDAO {
	
	/** logger */
	private static final Logger LOG = LoggerFactory.getLogger(EmployeeDAOStubImpl.class);
	private List<Employee> employeeList;
	
	/**
	 * Used by spring to initialize bean
	 */
	public void initialize() {
		LOG.info("Creating employee list for stub dao...");
		employeeList = new ArrayList<>();
		Employee employee = getEmployee();
		
		employeeList.add(employee);
	}

	/** {@inheritDoc} */
	@Override
	public List<Employee> findAll() {
		LOG.info("Getting employees from stub dao...");
		return employeeList;
	}

	/** {@inheritDoc} */
	@Override
	public Employee findById(long id) {
		LOG.info("Getting employee from stub dao by id {} ...", id);
		return employeeList.stream()
				.filter(employee -> employee.getId() == id)
				.findAny().get();
	}
	
	private Employee getEmployee() {
		Employee employee =  new Employee();
		employee.setId(1);
		employee.setFirstName("Alex");
		employee.setLastName("Harmensen");
		employee.setDepartment("Product Technology");
		return employee;
	}

	@Override
	public long add(Employee employee) {
		// TODO Auto-generated method stub
		return 0;
	}

}
