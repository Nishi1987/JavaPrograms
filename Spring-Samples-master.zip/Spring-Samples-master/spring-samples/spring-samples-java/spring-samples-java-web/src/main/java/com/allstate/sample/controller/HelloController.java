package com.allstate.sample.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HelloController {
	
	/** logger */
	private static final Logger LOG = LoggerFactory.getLogger(HelloController.class);
	
	@Autowired
	private MessageSource messageSource;
	
	@RequestMapping(value = "/greeting", method = RequestMethod.GET)
	public String hello(Model model) {
		LOG.info("Processing {} request...", "/greeting");
		LOG.info("Getting app.message from properties: {}", messageSource.getMessage("app.message", null, null, null));
		model.addAttribute("greeting", "Hello, World!");
		return "hello";
	}
}
