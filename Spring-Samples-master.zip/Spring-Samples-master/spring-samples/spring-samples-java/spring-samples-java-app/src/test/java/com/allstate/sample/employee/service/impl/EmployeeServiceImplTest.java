package com.allstate.sample.employee.service.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.allstate.sample.config.TestConfig;
import com.allstate.sample.employee.service.EmployeeService;
import com.allstate.sample.employee.service.dto.EmployeeDTO;

@ContextConfiguration(classes = TestConfig.class)
@RunWith(SpringRunner.class)
public class EmployeeServiceImplTest {
	
	@Autowired
	private EmployeeService employeeService;
	
	@Test
	public void contextLoads() {
		assertNotNull(employeeService);
	}
	
	@Test
	public void testGetEmployees() {
		List<EmployeeDTO> employeeList = employeeService.getEmployees();
		assertNotNull(employeeList);
		assertTrue(employeeList.size() > 0);
		assertEquals("Rikash", employeeList.get(0).getFirstName());
	}

}
