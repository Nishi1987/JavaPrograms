package com.allstate.sample.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;

@Configuration
@Import(AppConfig.class)
@EnableAspectJAutoProxy
public class TestConfig {

}
