package com.allstate.sample.employee.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.allstate.sample.employee.service.EmployeeService;
import com.allstate.sample.employee.service.dto.EmployeeDTO;

/**
 * Employee Service Implementation
 * 
 * @author rcho3
 *
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	/** logger */
	private static final Logger LOG = LoggerFactory.getLogger(EmployeeServiceImpl.class.getName());

	@Override
	public List<EmployeeDTO> getEmployees() {
		LOG.info("Getting employees...");
		List<EmployeeDTO> myEmployeeList = new ArrayList<>();
		EmployeeDTO employeeDTO = new EmployeeDTO();
		employeeDTO.setId(1);
		employeeDTO.setFirstName("Rikash");
		employeeDTO.setLastName("Choudhury");
		employeeDTO.setDepartment("Product Technology");
		myEmployeeList.add(employeeDTO);

		return myEmployeeList;
	}

}
