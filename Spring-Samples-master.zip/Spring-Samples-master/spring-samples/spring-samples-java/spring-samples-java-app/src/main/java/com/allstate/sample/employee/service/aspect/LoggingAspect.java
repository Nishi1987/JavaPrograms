package com.allstate.sample.employee.service.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {
	
	/** logger */
	private static final Logger LOG = LoggerFactory.getLogger(LoggingAspect.class.getName());
	
	@Pointcut("@target(org.springframework.stereotype.Service)")
    public void serviceMethods() {};
    
    /*@Pointcut("execution(* *..get*())")
    public void getMethods() {}
 
    @Pointcut("serviceMethods() && getMethods()")
    public void entityCreationMethods() {}*/
    
    @Before("serviceMethods()")
    public void logBeforeMethodCall(JoinPoint joinPoint) {
        String methodName = joinPoint.getSignature().getName();
        LOG.debug("Before " + methodName);
    }
    
    @After("serviceMethods()")
    public void logAfterMethodCall(JoinPoint joinPoint) {
        String methodName = joinPoint.getSignature().getName();
        LOG.debug("After " + methodName);
    }
    
    @Around("serviceMethods()")
    public Object measureMethodExecutionTime(ProceedingJoinPoint pjp) throws Throwable {
        long start = System.currentTimeMillis();
        Object retval = pjp.proceed();
        long end = System.currentTimeMillis();
        String methodName = pjp.getSignature().getName();
        LOG.info("Execution of " + methodName + " took " + (end - start) + " ms");
        
        return retval;
    }
    
}
