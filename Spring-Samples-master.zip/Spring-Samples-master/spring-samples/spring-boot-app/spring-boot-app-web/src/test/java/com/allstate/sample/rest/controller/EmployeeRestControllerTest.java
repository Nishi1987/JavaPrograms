package com.allstate.sample.rest.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class EmployeeRestControllerTest {
	
	private static final String EMPLOYEE_JSON = "[ {\"id\" : 1, \"firstName\" : \"Rikash\", \"lastName\" : \"Choudhury\",\"department\" : \"Product Technology\"} ]";
	
	@Autowired
	private MockMvc mvc;

	@Test
	public void testGetEmployees() throws Exception {
		mvc.perform(MockMvcRequestBuilders.get("/employees").accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
		.andExpect(content().json(EMPLOYEE_JSON));
	}
}
