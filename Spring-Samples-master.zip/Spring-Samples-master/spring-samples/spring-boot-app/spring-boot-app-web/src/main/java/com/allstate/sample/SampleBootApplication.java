package com.allstate.sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Spring Boot application launcher
 * @author rcho3
 *
 */
@SpringBootApplication
public class SampleBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleBootApplication.class, args);
	}
}
