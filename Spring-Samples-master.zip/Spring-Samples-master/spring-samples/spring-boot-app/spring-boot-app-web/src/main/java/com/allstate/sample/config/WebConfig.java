package com.allstate.sample.config;

import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

/**
 * Enable {@link EnableWebMvc} and {@link Configuration} only when customize Spring MVC.
 * <p>
 * Else, <b>spring.mvc.view.prefix</b> and <b>spring.mvc.view.suffix</b> is going 
 * to take care of setting it up. Refer application.properties</p>
 * <p> Once {@link EnableWebMvc} and {@link Configuration} added spring boot will 
 * switch off auto configuring Spring MVC</p>
 * @author rcho3
 *
 */
//@EnableWebMvc
//@Configuration
public class WebConfig extends WebMvcConfigurerAdapter {

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController("/");
	}

	@Bean
	public ViewResolver viewResolver() {
		InternalResourceViewResolver bean = new InternalResourceViewResolver();

		bean.setViewClass(JstlView.class);
		bean.setPrefix("/WEB-INF/jsp/");//same as spring.mvc.view.prefix
		bean.setSuffix(".jsp");//same as spring.mvc.view.suffix

		return bean;
	}
}
