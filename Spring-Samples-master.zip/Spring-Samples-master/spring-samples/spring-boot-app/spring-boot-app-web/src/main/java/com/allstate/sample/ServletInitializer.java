package com.allstate.sample;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

/**
 * Custom Servlet Initializer for application using {@link SpringBootServletInitializer} 
 * @author rcho3
 *
 */
public class ServletInitializer extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(SampleBootApplication.class);
	}

}
