package com.allstate.sample.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.allstate.sample.employee.service.EmployeeService;
import com.allstate.sample.employee.service.dto.EmployeeDTO;

@RestController
public class EmployeeRestController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("/employees")
	public ResponseEntity<List<EmployeeDTO>> getEmployees() {
		return ResponseEntity.ok().body(employeeService.getEmployees());
	} 
}
