package com.allstate.sample.employee.service;

import java.util.List;

import com.allstate.sample.employee.service.dto.EmployeeDTO;

/**
 * Employee Service
 * 
 * @author rcho3
 *
 */
public interface EmployeeService {
	
	/**
	 * Returns all the employees
	 * @return
	 */
	public List<EmployeeDTO> getEmployees();
}
